# API: 게시물 캡션(텍스트) 생성
- **Endpoint**: `POST /api/v1/contents/caption`
- **역할**: 사용자의 발화(utterance)를 기반으로 AI를 통해 인스타그램 게시물 캡션을 생성하거나, 생성에 필요한 참고 정보(Context)를 반환합니다.

## 1. 참조 DB 및 외부 서비스
- **참조 DB**: 
  - `StoreRepository` (PostgreSQL): 매장 정보 및 페르소나 조회
  - `ContentRedisRepository` (Redis): 멱등성 검증 키 저장 및 세션 데이터(캡션, 상태) 캐싱
- **외부 서비스**: 
  - `AiContentClient`: FastAPI 기반 AI 모델에 캡션 생성 요청
  - `WeatherContextProvider`: 기상청/환경공단 API를 통한 날씨 및 대기질 정보 조회 (내부 Redis 캐싱 포함)

## 2. 처리 로직 및 순서 (조회-처리-저장)
본 API는 `request_id`의 존재 여부에 따라 두 가지 로직으로 분기됩니다.

### A. 신규 요청 (`request_id` 없음) - 참고 정보 반환
1. **조회**: `storeId` 또는 인증된 `userId`를 통해 `Store` 정보를 RDB에서 조회합니다.
2. **처리**: 매장 정보(주소, 좌표)를 기반으로 `WeatherService`를 통해 현재 날씨 컨텍스트를 가져옵니다.
3. **저장/반환**: DB 저장 없이 Store 정보, 페르소나, 날씨, 발화를 포함한 참고 JSON을 클라이언트에게 반환합니다.

### B. 기존 요청 (`request_id` 존재) - AI 캡션 생성
1. **조회 (멱등성 검증)**: Redis에 `request_id` 기반 키를 SET NX EX로 생성 시도하여 중복 요청인지 검증합니다.
2. **처리**: 
   - 중복 요청 시: FastAPI 호출 없이 Redis에 기저장된 `existingSessionId`를 바탕으로 기존 결과를 즉시 반환합니다.
   - 최초 요청 시: `Store` 정보 및 `Weather` 컨텍스트를 조회하고, FastAPI(`aiContentClient.processUtterance`)를 호출하여 캡션과 가이드 텍스트를 생성합니다.
3. **저장**: 
   - 최초 요청 전에 Redis에 임시 세션 정보를 초기화합니다.
   - FastAPI 응답 후 Redis(`contents:{sessionId}`)에 AI가 생성한 가이드 텍스트, 캡션, 상태(`TEXT_GENERATED`)를 업데이트합니다.

## 3. 에러 대응책
- `ErrorCode.EMPTY_UTTERANCE`: 발화 내용이 없을 때 예외 발생.
- `ErrorCode.INVALID_REQUEST`: `request_id` 형식이 잘못되었을 때 예외 발생.
- `ErrorCode.STORE_NOT_FOUND`: 매장 정보를 찾을 수 없을 때 예외 발생.
- `ErrorCode.AI_SERVER_FAILED`: AI 서버 장애 시 발생하며, Redis 멱등성 처리 중 `session_id`가 증발하는 Race Condition 발생 시에도 차단용으로 사용.

## 4. 리팩토링 제안
- **API 분리 (SRP 원칙)**: 현재 하나의 Endpoint가 `request_id` 존재 여부에 따라 완전히 다른 두 가지 역할(단순 Context 조회 vs AI 생성 트리거)을 수행하고 있습니다. 이를 `GET /caption-context`와 `POST /caption`으로 분리하여 의도를 명확히 하는 것이 좋습니다.
- **Redis 만료 및 Race Condition 해소**: 주석에 명시된 대로 멱등성 키 만료 시점의 Race Condition 이슈가 존재합니다. 멱등성 처리를 단순 SET NX에 의존하기보다, Redisson 기반의 분산 락을 도입하거나 Redis Hash 상태값을 세밀하게 두어(처리중/완료/실패) 처리 상태를 안전하게 제어해야 합니다.
