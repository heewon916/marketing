# API: 게시물 발행 요청 (큐잉)
- **Endpoint**: `POST /api/v1/contents/{sessionId}/publish`
- **역할**: 편집이 완료된 임시저장 게시물을 실제 인스타그램 등에 발행하기 위해 비동기 발행 대기열(Queue)에 등록하는 역할을 시뮬레이션(표시)합니다.

## 1. 참조 DB 및 외부 서비스
- **참조 DB**: `ContentRedisRepository` (Redis)
- **외부 서비스**: 없음

## 2. 처리 로직 및 순서 (조회-처리-저장)
1. **처리**: 발행 식별용으로 사용할 고유 식별자(`publishId`)를 UUID로 생성합니다.
2. **저장 (상태 갱신)**: Redis의 해당 세션 정보에 접근하여 상태를 갱신하거나 발행 대기열 필드(`queuePublish`)에 `publishId`를 저장합니다.
3. **반환**: `publish_progress` 상태를 `"queued"`로 명시하여 즉시 클라이언트에 응답을 반환합니다. (실제 인스타그램 API 전송 등의 무거운 작업은 이 단계에서 동기적으로 진행하지 않습니다.)

## 3. 에러 대응책
- `ErrorCode.CONTENT_NOT_FOUND`: Redis에 세션이 존재하지 않아 대기 상태로 변경(`queuePublish`)하는 것에 실패했을 경우 예외 처리.

## 4. 리팩토링 제안
- **실제 메시지 큐 연동 부족**: 현재 로직은 Redis 필드만 갱신할 뿐, 백그라운드 Worker(예: Spring @Async, RabbitMQ, Kafka, AWS SQS)를 트리거하여 인스타그램 Graph API를 호출하는 실제 '발행' 로직이 연결되어 있지 않습니다. 이 API가 호출될 때 실제 이벤트 기반 워커가 동작하도록 이벤트 발행 로직(`ApplicationEventPublisher` 등)을 추가해야 합니다.
