# API: 임시저장 게시물 이미지 삭제
- **Endpoint**: `DELETE /api/v1/contents/{sessionId}/images/delete`
- **역할**: 게시물에 포함된 여러 장의 사진 중 특정 사진 하나를 임시저장(Redis) 상태에서 삭제합니다.

## 1. 참조 DB 및 외부 서비스
- **참조 DB**: `ContentRedisRepository` (Redis)
- **외부 서비스**: 없음

## 2. 처리 로직 및 순서 (조회-처리-저장)
1. **조회 (Validation)**: 클라이언트가 전달한 `deletedImageKey`가 비어있지 않은지 확인합니다.
2. **처리 및 저장 (Redis 반영)**: 
   - `ContentRedisRepository`를 통해 해당 세션 키(`contents:{sessionId}`) 하위의 특정 Hash Field(`deletedImageKey`)를 삭제(`HDEL`)합니다.
   - 삭제 작업 후, 세션에 남아있는 나머지 이미지의 개수(`HLEN` 또는 리스트 사이즈 조회)를 다시 가져옵니다.
3. **반환**: 삭제 성공 여부와 남은 이미지 개수를 반환합니다.

## 3. 에러 대응책
- `ErrorCode.INVALID_REQUEST`: 삭제하려는 이미지의 Key가 누락되었거나 빈 값일 때 발생합니다.
- `ErrorCode.CONTENT_IMAGE_NOT_FOUND`: Redis 삭제 명령 결과가 실패(이미 해당 Key가 존재하지 않음)일 경우 예외를 던집니다.

## 4. 리팩토링 제안
- **S3 고아 객체(Orphaned Object) 처리 누락**: 현재 Redis에서만 이미지의 참조 URL을 지우고 있으며, 실제 S3 버킷에 존재하는 이미지 파일(Object)은 삭제하지 않고 있습니다. 이는 장기적으로 S3 용량 낭비 및 비용 증가로 이어집니다. 삭제된 이미지 목록을 S3에 즉시 반영하여 지우거나, 삭제 이벤트를 큐에 담아 배치로 S3 객체를 정리(Garbage Collection)하는 로직이 추가되어야 합니다.
- **RESTful URI 컨벤션**: Endpoint가 `/{sessionId}/images/delete`로 구성되어 있으나, HTTP Method가 `DELETE`이므로 `DELETE /{sessionId}/images/{imageKey}` 형태로 Path Variable을 사용하는 것이 더욱 RESTful한 설계입니다.
