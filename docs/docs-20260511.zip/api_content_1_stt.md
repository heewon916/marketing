# API: 음성 인식 (STT) 처리
- **Endpoint**: `POST /api/v1/contents/stt`
- **역할**: 사용자가 녹음한 음성 파일을 텍스트(utterance)로 변환하여 반환합니다.

## 1. 참조 DB 및 외부 서비스
- **참조 DB**: 없음
- **외부 서비스**: 
  - `ClovaSttClient`: 네이버 Clova STT API를 호출하여 음성을 텍스트로 변환

## 2. 처리 로직 및 순서 (조회-처리-저장)
1. **조회 (Validation)**:
   - 클라이언트로부터 전달받은 `MultipartFile audioFile`의 존재 여부 및 비어있는지 확인합니다.
   - `Content-Type`과 파일 확장자를 기반으로 허용된 오디오 파일(wav, mp3, mp4 등)인지 1차 검증합니다.
2. **처리**:
   - `ClovaSttClient`에 오디오 파일을 전달하여 STT 변환을 요청합니다.
   - 변환된 텍스트(`utterance`)를 반환받습니다.
3. **저장**:
   - 별도의 DB 저장은 발생하지 않으며, 상태값(`TEXT_RECOGNIZED`)과 함께 즉시 클라이언트에게 반환합니다.

## 3. 에러 대응책
- `ErrorCode.INVALID_AUDIO_FILE`: 파일이 비어있거나, 허용되지 않은 Content-Type 혹은 확장자일 경우 발생합니다. Spring단에서 외부 API 호출 전에 예외를 발생시켜 불필요한 API 호출 비용 및 장애를 방지합니다.
- 외부 API 장애 대응: `clovaSttClient` 내부적으로 예외 처리가 되어있어야 하며, 실패 시 클라이언트에 500 에러를 반환합니다.

## 4. 리팩토링 제안
- **파일 타입 검증 고도화**: 현재는 클라이언트가 전달하는 `Content-Type`과 확장자 문자열에 의존하고 있어 조작이 가능합니다. Apache Tika 등을 활용해 파일의 실제 Magic Number를 분석하여 MimeType을 검증하는 방식으로 보안을 강화할 수 있습니다.
- **하드코딩 제거**: 응답 상태값인 `"TEXT_RECOGNIZED"`가 문자열로 선언되어 있습니다. `ContentStatus` Enum 등으로 통합 관리하는 것이 유지보수에 좋습니다.
