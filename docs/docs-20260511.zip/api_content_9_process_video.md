# API: 비디오 업로드 및 AI 프레임 추출
- **Endpoint**: `POST /api/v1/contents/{sessionId}/video`
- **역할**: 클라이언트가 촬영한 비디오를 S3에 업로드하고, AI 모델을 호출하여 비디오에서 프레임(이미지)을 추출 및 보정한 뒤 결과 이미지들의 S3 URL을 반환합니다.

## 1. 참조 DB 및 외부 서비스
- **참조 DB**: `ContentRedisRepository` (Redis) - S3 비디오 키와 AI 추출 이미지 결과 상태 캐싱
- **외부 서비스**: 
  - `S3VideoClient`: 원본 mp4 비디오 파일 업로드
  - `AiContentClient` (FastAPI): `/extract-frames` (프레임 추출) 및 `/final-edit` (사진 보정 및 편집) 두 가지 AI 파이프라인 동기 호출

## 2. 처리 로직 및 순서 (조회-처리-저장)
1. **조회 (Validation)**: 전달받은 `videoFile`의 누락이나 빈 파일 여부를 검증합니다.
2. **처리 및 저장 1 (S3)**: S3 버킷 내 정해진 경로(`/inputs/{sessionId}/draft.mp4`)에 비디오 파일을 업로드하고, 결과 Key를 Redis에 반영(`putVideo`)합니다.
3. **처리 2 (AI 파이프라인 연동)**:
   - FastAPI 서버에 S3 키를 전달하여 프레임 추출을 요청(`extractFrames`)하고 `drafts` 이미지 URL 목록을 받습니다.
   - 받아온 `drafts` 목록을 다시 FastAPI 서버에 전달하여 최종 보정을 요청(`finalEdit`)하고 `results` 이미지 URL 목록과 상태를 받습니다.
4. **저장 (Redis)**: 비디오 S3 키, AI 처리 상태, 초안 이미지, 최종 결과 이미지를 Redis 해시에 통째로 저장(`putAiVideoResults`)합니다.
5. **반환**: 각 결과 이미지에 고유 식별자(UUID)를 부여하여 클라이언트가 렌더링할 수 있도록 목록을 반환합니다.

## 3. 에러 대응책
- `ErrorCode.INVALID_REQUEST`: 영상 파일이 없을 경우 예외 처리.
- `ErrorCode.CONTENT_NOT_FOUND`: Redis에 비디오 키 업데이트가 실패했을 경우.
- AI 클라이언트의 응답이 null일 경우 빈 리스트(`List.of()`)로 Fallback 처리하여 서버 패닉(NPE)을 방지합니다.

## 4. 리팩토링 제안
- **과도한 동기 지연 타임아웃 위험**: 파일 크기가 큰 비디오를 S3에 직접 업로드하는 대기 시간과, 두 번의 무거운 무거운 AI 비전 모델 파이프라인(프레임 추출, 보정)을 모두 **동기적(Synchronous)으로** 기다리고 있습니다. 이는 클라이언트 측 Timeout(504 Gateway Timeout)을 유발하기 매우 쉽습니다.
- **해결책 (비동기 처리 도입)**: 클라이언트에게는 파일 S3 업로드만 완료되면 `202 Accepted`를 응답하고, AI 프레임 추출은 메시지 큐나 비동기 이벤트로 넘겨야 합니다. 프론트엔드는 SSE(Server-Sent Events)나 Webhook, 혹은 Polling 방식으로 작업 완료(상태 변경)를 통지받고 결과를 조회하도록 전면적인 아키텍처 개편이 필수적입니다.
- **Pre-signed URL 활용**: 파일 업로드를 백엔드가 직접 중개하면 네트워크 병목이 생깁니다. 클라이언트가 S3 Pre-signed URL을 발급받아 S3로 직결 업로드하게 만들면 서버 부하를 크게 낮출 수 있습니다.
