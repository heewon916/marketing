# API: 임시저장 게시물 텍스트 수정
- **Endpoint**: `PATCH /api/v1/contents/{sessionId}/edit`
- **역할**: AI가 초안으로 생성한 게시글 캡션을 사용자가 직접 수정한 내용으로 임시저장합니다.

## 1. 참조 DB 및 외부 서비스
- **참조 DB**: `ContentRedisRepository` (Redis)
- **외부 서비스**: 없음

## 2. 처리 로직 및 순서 (조회-처리-저장)
1. **조회 (Validation)**: 요청으로 들어온 `caption` 텍스트가 유효한지(null 또는 blank 여부) 확인합니다.
2. **처리 및 저장**: 
   - Redis의 해당 세션 Hash(`contents:{sessionId}`)에 접근하여 `caption` 필드를 새 값으로 덮어씁니다 (`HSET`).
   - 갱신 시간(`updated_at`)도 백엔드 서버 기준으로 측정하여 Redis에 함께 저장합니다.
3. **반환**: 수정된 캡션과 갱신 시간을 클라이언트로 반환합니다.

## 3. 에러 대응책
- `ErrorCode.INVALID_REQUEST`: 수정하려는 캡션이 비어있을 경우 요청을 거절합니다.
- `ErrorCode.CONTENT_NOT_FOUND`: Redis에 해당 세션 데이터가 없어 업데이트가 실패한 경우 예외를 발생시킵니다. (세션 만료 등)

## 4. 리팩토링 제안
- **갱신 로직의 파편화 방지**: 현재 캡션 하나만 수정 가능하지만, 이후 해시태그 추가, 이미지 순서 변경 등 다른 수정 요구사항이 발생할 수 있습니다. `ContentEditRequestDto`를 유연하게 설계하여 여러 필드의 `Partial Update`가 가능하게끔 Redis HSET MSET 로직을 확장성 있게 구성하는 것이 좋습니다.
