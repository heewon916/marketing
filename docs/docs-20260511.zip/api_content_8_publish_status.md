# API: 게시물 발행 상태 조회 및 DB 반영
- **Endpoint**: `GET /api/v1/contents/{sessionId}/publish/status`
- **역할**: 클라이언트가 폴링(Polling) 방식으로 게시물의 발행 상태를 조회할 때 사용되며, 발행 성공 시 PostgreSQL(RDB)에 최종 영속화를 수행합니다.

## 1. 참조 DB 및 외부 서비스
- **참조 DB**: 
  - `ContentRedisRepository` (Redis): 발행 상태 및 세션 데이터 조회
  - `ContentRepository` (PostgreSQL): 최종 발행 완료된 게시물 데이터 영구 저장

## 2. 처리 로직 및 순서 (조회-처리-저장)
1. **조회 (캐시)**: Redis에서 세션 정보(`sessionId`)를 가져옵니다.
2. **조건 분기 (이미 완료된 경우)**: Redis 세션 데이터 내에 이미 `contentId`(RDB 식별자)가 존재한다면, 더 이상의 로직 수행 없이 즉시 `completed` 상태와 Instagram URL을 반환합니다.
3. **처리 및 저장 (미완료된 경우 - 최종 발행 로직 수행)**:
   - 세션에 `storeId`가 유효한지 검증합니다.
   - 인스타그램 Media ID 및 Permalink를 생성합니다. (현재는 `"local-" + sessionId` 형태의 Mock 데이터로 시뮬레이션 중입니다.)
   - `Content` 엔티티 객체를 빌더로 생성하여 RDB(`ContentRepository`)에 `save()`를 수행합니다. (이미지와 비디오 URL 정보도 함께 매핑하여 저장)
   - 생성된 RDB PK값(`saved.getId()`)과 Mock URL 정보를 Redis 세션에 업데이트(`completePublish`)하여 중복 저장을 방지합니다.
4. **반환**: `completed` 상태 및 RDB 엔티티 ID를 반환합니다.

## 3. 에러 대응책
- `ErrorCode.CONTENT_NOT_FOUND`: 세션 정보를 Redis에서 찾을 수 없을 때.
- `ErrorCode.STORE_NOT_FOUND`: 세션에 매장 식별자(`storeId`)가 없어 RDB에 연관 관계를 맺을 수 없을 때 예외 처리.

## 4. 리팩토링 제안
- **HTTP Method의 멱등성 위배 (CRITICAL)**: `GET` 메서드는 상태를 변경하지 않는 멱등성을 가져야 하나, 본 API는 `GET` 호출 시 RDB에 데이터를 `INSERT`하는 심각한 상태 변경을 유발합니다. 이는 REST 원칙에 어긋납니다. 최종 DB 저장은 백그라운드 Worker가 인스타그램 발행을 성공한 직후 내부적으로 처리하고, 이 엔드포인트는 순수하게 DB 또는 Redis를 "조회"만 하도록 분리되어야 합니다.
- **Mock 데이터 제거**: 현재 인스타그램 Media ID 등이 하드코딩된 모의 데이터입니다. 실제 인스타그램 API 연동 로직 적용이 필요합니다.
