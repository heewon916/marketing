# API: 임시저장 게시물 전체 조회
- **Endpoint**: `GET /api/v1/contents/{sessionId}`
- **역할**: 현재 편집 중인 임시저장 게시물의 모든 정보(상태, 캡션, 이미지 리스트) 및 사용자의 인스타그램 프로필 연동 정보를 함께 제공합니다.

## 1. 참조 DB 및 외부 서비스
- **참조 DB**: `ContentRedisRepository` (Redis)
- **외부 서비스**: 없음 (인증 정보는 Spring Security Context 활용)

## 2. 처리 로직 및 순서 (조회-처리-저장)
1. **조회 (세션/인증)**:
   - Redis에서 `sessionId`를 키로 하여 세션 정보(`ContentRedisSession`) 전체를 조회합니다.
   - Spring Security의 `SecurityContextHolder`를 통해 현재 로그인한 사용자(`AuthUser`)의 정보를 가져옵니다.
   - Redis에서 사진 URL 리스트를 한 번 더 별도로 조회합니다(`getPhotoUrls`).
2. **처리**: 
   - 조회된 사진들을 `display_order` 등의 메타데이터와 함께 DTO 규격으로 매핑합니다.
   - 세션의 상태값이 비어있을 경우 기본값 `"draft"`로 정규화합니다.
3. **반환**: 캡션, 이미지 목록, 상태값과 함께 `AuthUser`에서 추출한 사용자의 인스타그램 아이디 및 프로필 이미지 URL을 병합하여 반환합니다.

## 3. 에러 대응책
- `ErrorCode.CONTENT_NOT_FOUND`: Redis에 해당 세션(`sessionId`)이 존재하지 않거나 만료된 경우 예외 처리.
- `ErrorCode.UNAUTHORIZED_USER`: Security Context에서 사용자 정보를 가져오지 못하거나 타입 캐스팅에 실패한 경우 차단.

## 4. 리팩토링 제안
- **Redis 조회 최적화 (N+1 방지)**: 현재 `getRedisSessionOrThrow`에서 세션 전체를 조회한 직후, `getPhotoUrls`를 통해 사진 정보들을 또다시 조회하고 있습니다. Redis Hash 자료구조를 효율적으로 설계했다면 단일 파이프라이닝이나 `HGETALL` 한 번으로 모든 정보를 가져와 조립할 수 있습니다. 불필요한 Redis 통신 횟수를 줄이는 것이 좋습니다.
